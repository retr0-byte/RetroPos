<p align="center"><img src="./screenshot/logo.ico" width="150px" height="150px" alt="aventium softworks"></p>

<h1 align="center">MHDDoS - Layer7 DDoS Attack Script</h1>

<em><h5 align="center">(Code Lang - Python 3)</h5></em>


<p align="center">Please Dont Hit '.gov'  and '.ir' Websites :)</p>

<p align="center"><img src="https://i.imgur.com/aNrHJcA.png" width="1078" height="433" alt="aventium softworks"></p>
<p align="center"><img src="https://i.imgur.com/ueDhdte.png" width="1078" height="296" alt="aventium softworks"></p>

## Features And Method

 * 💣 Layer7
   * BYPASS |  Bypass Normal AntiDDoS
   * GET | GET Flood
   * POST | POST Flood
   * OVH | Bypass OVH
   * STRESS | Send HTTP Packet With High Byte 
   * OSTRESS | STRESS Without Proxy
   * DYN | A New Method With Random SubDomain
   * SLOW | Slowloris Old Method of DDoS
   * HEAD | https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods/HEAD
   * HIT | POST Without PROXY
   * NULL | Null UserAgent and ...
   * COOKIE | Random Cookie PHP 'if (isset($_COOKIE))'
   * BRUST | A Method with more header
   * PPS | No Header Only 'GET / HTTP/1.1\r\n\r\n'
   * EVEN | GET Method with more header
   * GSB | Google Project Shield Bypass
   * DGB | DDoS Guard Bypass
   * AVB | Arvan Cloud Bypass
   * CFB | CloudFlare Bypass

* 🧨 Layer4: 
  * TCP | TCP Flood Bypass
  * UDP | UDP Flood Bypass
  * SYN | SYN Flood
  * VSE | VSE Flood Only Connection
  * MEM | Memcached Flood
  * NTP | NTP Flood OLD Method Of Layer4

* 🏹 Layer3
  * ICMP | Flood ICMP Request
  * POD | Ping Of Death OLD Method Of DDoS

* ⚙️ Tools - Run With 'python3 start.py tools'
  * CFIP | Find Real IP address of Website Powered by Cloudflare
  * DNS | Find WebSite DNS
  * PING | PING server
  * CHECK | Check Website is Die or no
  * DSTAT | a Method show Receive And Send Bytes Size

* 🎩 Other
  * STOP | STOP All Attacks
  * TOOLS | Tools Console
  * HELP | Show Usge Script

#### Issues ? 
 * Telegram : @MH_ProDev_IR
 * Discord : MH_ProDev#5642
 * [GitHub][github]
#### Like the project? Leave a ⭐ star on the repository!

## Downloads

You can download from [GitHub Releases](https://github.com/MHProDev/MHDDoS/releases)

### Getting Started

**Requirements**

* [Python3][python3]
* Python-pip3
* requests
* PySocks
* cfscrape
* icmplib
* scapy
---

**Video's**

* Aparat: https://www.aparat.com/v/bHcP9
* YouTube : Comming soon..

*toturial*

* Aprat : Comming soon..
* YouTube : Comming soon..

---

**Clone and Install Script**

```console
> git clone https://github.com/MHProDev/MHDDoS.git
> cd MHDDoS
> pip3 install -r requirements.txt
```

---

**Launch Script**

```console
> python3 MHDDoSLayer7v1.py
```

[python3]: https://python.org 'Python3'
[github]: https://github.com/MHProDev/MHDDoS/issues 'GitHub'
